<?php

//Login data for our database. We must use this file in all Models
$host = "localhost";
$user = "root";
$passwd = "";
$database = "lovcafedb";

?>
