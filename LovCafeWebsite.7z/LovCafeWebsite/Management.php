<?php
$title = "Management";

$content = '<h3>Dishes</h3>
            <a href="DishAdd.php">Add A New Dish</a><br/>
            <a href="UploadImage.php">Upload Image</a><br/>
            <a href="DishOverview.php">Overview of Dish</a><br/>';

include './Template.php';
?>
