-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2018 at 11:41 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lovcafedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `house` varchar(30) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `area` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `joinDate` date NOT NULL,
  `customer_password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dish`
--

CREATE TABLE `dish` (
  `dish_id` int(11) NOT NULL,
  `dish_name` varchar(30) NOT NULL,
  `dish_type` varchar(30) NOT NULL,
  `dish_image` varchar(50) NOT NULL,
  `dish_description` varchar(500) NOT NULL,
  `dish_price` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dish`
--

INSERT INTO `dish` (`dish_id`, `dish_name`, `dish_type`, `dish_image`, `dish_description`, `dish_price`) VALUES
(13, 'Spaghetti aglio e olio peperon', 'Pasta', 'LovCafeWebsite\\Images\\spaghetti aglio, olio e.jpg', 'made by lightly sauteeing sliced, minced, or pressed garlic in olive oil, with the addition of dried', 250),
(14, 'Spaghetti al pomodoro', 'Pasta', 'LovCafeWebsite\\Images\\spaghetti al pomodoro.jpg', 'prepared with pasta, olive oil, fresh tomatoes, basil, and various other fresh ingredients. intended', 300),
(15, 'Pasta alla genovese', 'Pasta', 'LovCafeWebsite\\Images\\pasta alla genovese.jpg', 'classic Ligurian dish, with basil pesto gently coating al dente pasta, cubed potato and green beans.', 320),
(16, 'Carbonara', 'Pasta', 'LovCafeWebsite\\Images\\carbonara.jpg', 'Spaghetti, Fettuccine, Rigatoni or, Bucatini tossed with beef pancetta, olive oil and pepper, served ina creamy sauce of egg andparmesan cheese.', 400),
(17, 'Cappuccino         ', 'Drinks', 'LovCafeWebsite\\Images\\Cappuccino.jpg', 'coffee-based drink made primarily from espresso and milk. consists of one-third espresso, one-third heated milk and one-third milk foam and is generally served in a 6 to 8-ounce cup.', 150),
(18, 'Bicerin', 'Drinks', 'LovCafeWebsite\\Images\\Bicerin.jpg', 'made of espresso, drinking chocolate, and whole milk served layered in a small rounded glass. may be used instead of milk according to choice.', 180),
(19, 'Espressino', 'Drinks', 'LovCafeWebsite\\Images\\carbonara.jpg', 'made from equal parts espresso, Nutella all over the wall of the cup, with some cocoa powder on the bottom of the cup and on top of the drink, and a part of milk as well.', 120),
(20, 'Caffè corretto', 'Drinks', 'LovCafeWebsite\\Images\\Caffè_corretto.jpg', 'consists of a shot of espresso with a small amount of liquor, usually grappa, and sometimes sambuca or brandy.', 300),
(21, 'Pizza Capricciosa', 'Pizza', 'LovCafeWebsite\\Images\\Pizza_capricciosa.jpg', 'prepared with mozzarella cheese, Italian baked ham, mushroom, artichoke and tomato. Types of edible mushrooms used may include cremini, white mushrooms, and others. Some versions may also use prosciutto (a dry-cured ham), marinated artichoke hearts, olive oil, olives, basil leaves and egg.', 700),
(22, 'Neapolitan Pizza', 'Pizza', 'LovCafeWebsite\\Images\\Neapolitan Pizza.jpg', 'made with tomatoes and mozzarella cheese. also be made with San Marzano tomatoes, and Mozzarella, a protected designation of origin cheese made with the milk from water buffalo and Lazio.', 850),
(23, 'Pizza Pugliese', 'Pizza', 'LovCafeWebsite\\Images\\Pizza Pugliese.jpg', ' prepared with tomato, onion, and mozzarella. Variations exist, in which different cheeses and ingredients may be added. Some versions may also use oregano, olives and capers as ingredients, and some may omit the use of pizza sauce and substitute half of the mozzarella with Provolone cheese that is sliced or grated. Some versions may use pecorino cheese.', 790),
(24, ' Pizza Quattro Stagioni', 'Pizza', 'LovCafeWebsite\\Images\\stagioni.jpg', 'prepared in four sections with diverse ingredients, with each section representing one season of the year. typically prepared using artichokes, tomatoes or basil, mushrooms and ham or prosciutto, or olives. The artichokes represent spring, tomatoes or basil represent summer, mushrooms represent autumn and the ham or olives represent winter. Other ingredients may also be used. It is typically prepared using a tomato sauce and cheese. Fresh-cooked or canned artichoke hearts may be used.', 950),
(25, 'Tiramisu', 'Dessert', 'LovCafeWebsite\\Images\\Tiramisu.jpg', 'coffee-flavoured Italian dessert. It is made of ladyfingers dipped in coffee, layered with a whipped mixture of eggs, sugar, and mascarpone cheese, flavoured with cocoa. ', 350),
(26, 'Cassata', 'Dessert', 'LovCafeWebsite\\Images\\cassata.jpeg', 'onsists of round sponge cake moistened with fruit juices or liqueur and layered with ricotta cheese and candied fruit, a filling also used with cannoli. Cassata has a shell of marzipan, pink and green coloured icing, and decorative designs. ', 400),
(27, 'Zeppole', 'Dessert', 'LovCafeWebsite\\Images\\Zeppole.jpg', 'consisting of a deep-fried dough ball of varying size but typically about 4 inches (10 cm) in diameter. This doughnut or fritter is usually topped with powdered sugar, and may be filled with custard, jelly, cannoli-style pastry cream, or a butter-and-honey mixture. The consistency ranges from light and puffy, to bread- or pasta-like.', 320),
(28, 'Budino', 'Dessert', 'LovCafeWebsite\\Images\\Budino.jpg', 'sweet Italian dish, usually rich and creamy like a custard or pudding. The word originally referred to a type of medieval sausage, similar to English pudding. It can be thickened with cornstarch or cookies to make it more a soufflé or ganache, and can be sauced with various flavors, including chocolate, caramel, apple, and butterscotch.', 470);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `house` varchar(30) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `area` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `joinDate` date NOT NULL,
  `job_type` varchar(30) NOT NULL,
  `salary` double NOT NULL,
  `employee_password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `dish_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `dish`
--
ALTER TABLE `dish`
  ADD PRIMARY KEY (`dish_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`dish_id`,`order_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dish`
--
ALTER TABLE `dish`
  MODIFY `dish_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`),
  ADD CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`dish_id`) REFERENCES `dish` (`dish_id`);

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
