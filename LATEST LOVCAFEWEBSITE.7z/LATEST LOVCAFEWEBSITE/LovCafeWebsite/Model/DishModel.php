<?php

require 'Entities/DishEntity.php';

//Contains database-related-codes
class DishModel {

    //For fetching all dish types from db & return them in an array
    function GetDishTypes() {
        require 'Credentials.php';
        //Opening connection and choosing database   
        $link = mysqli_connect($host, $user, $passwd, $database);
        if(!$link) {
			echo "Error: Unable to connect to MySQL.".PHP_EOL;
			echo "Debugging errno".mysqli_connect_errno().PHP_EOL;
			echo "Debugging error".mysqli_connect_error().PHP_EOL;
			exit;
		}
		
        $result = mysqli_query($link, "SELECT DISTINCT dish_type FROM dish");
        $types = array();

        //Getting data from database
        while($row = mysqli_fetch_array($result)) {
            array_push($types, $row[0]);
        }
		mysqli_free_result($result);
        //Closing connection & returning desired result
        mysqli_close($link);
        return $types;
    }

    
    //Getting DishEntity objects from database & return them in an array
    function GetDishByType($type) {
        require 'Credentials.php';
        //Opening connection and choosing database     
        $link = mysqli_connect($host, $user, $passwd, $database);
        if(!$link) {
			
			echo "Error:Unable to connect to MySQL.".PHP_EOL;
			echo "Debugging errno: ".mysqli_connect_errno().PHP_EOL;
			echo "Debugging error: ".mysqli_connect_error().PHP_EOL;
		exit;
		}
        $query = "SELECT * FROM dish WHERE dish_type LIKE '$type'";
        $result = mysqli_query($link, $query);
        $dishArray = array();

        //Fetching data from database
        while ($row = mysqli_fetch_array($result)) {
            $id = $row[0];
            $name = $row[1];
            $type = $row[2];
            $image = $row[3];
            $description = $row[4];

            //Creating dish objects & storing them in an array
            $dish = new DishEntity($id, $name, $type, $image, $description);
            array_push($dishArray, $dish);
        }
		mysqli_free_result($result);
        //Closing connection & returning desired result
        mysqli_close($link);
        return $dishArray;
    }

    function GetDishById($id) {
        require 'Credentials.php';
        //Open connection and Select database.     
        $link = mysqli_connect($host, $user, $passwd, $database);
        if(!$link) {
			
			echo "Error:Unable to connect to MySQL.".PHP_EOL;
			echo "Debugging errno: ".mysqli_connect_errno().PHP_EOL;
			echo "Debugging error: ".mysqli_connect_error().PHP_EOL;
		exit;
		}
        $query = "SELECT * FROM dish WHERE dish_id = $id";
        $result = mysqli_query($link, $query);

        //Get data from database.
        while ($row = mysqli_fetch_array($result)) {
            $name = $row[1];
            $type = $row[2];
            $image = $row[3];
            $description = $row[4];

            //Create dishes
            $dish = new DishEntity($id, $name, $type, $image, $description);
        }
		mysqli_free_result($result);
        //Close connection and return result
        mysqli_close($link);
        return $dish;
    }

    function InsertDish(DishEntity $dish) {
        require 'Credentials.php';
        //Opening connection and choosing database   
        $link = mysqli_connect($host, $user, $passwd, $database);
        if(!$link) {
			echo "Error: Unable to connect to MySQL.".PHP_EOL;
			echo "Debugging errno".mysqli_connect_errno().PHP_EOL;
			echo "Debugging error".mysqli_connect_error().PHP_EOL;
			exit;
		}
        
        $query = sprintf("INSERT INTO dish
                          (dish_name, dish_type, dish_image, dish_description)
                          VALUES
                          ('%s','%s','%s','%s')",
                mysqli_real_escape_string($link, $dish->dish_name),
                mysqli_real_escape_string($link, $dish->dish_type),
                mysqli_real_escape_string($link, "Images/Dish/" . $dish->dish_image),
                mysqli_real_escape_string($link, $dish->dish_description));
        $this->PerformQuery($query);
    }

    function UpdateDish($id, DishEntity $dish) {
        require 'Credentials.php';
        //Opening connection and choosing database   
        $link = mysqli_connect($host, $user, $passwd, $database);
        if(!$link) {
			echo "Error: Unable to connect to MySQL.".PHP_EOL;
			echo "Debugging errno".mysqli_connect_errno().PHP_EOL;
			echo "Debugging error".mysqli_connect_error().PHP_EOL;
			exit;
		}
		
		$query = sprintf("UPDATE dish
                            SET dish_name = '%s', dish_type = '%s', dish_image = '%s', dish_description = '%s'
                          WHERE dish_id = $id",
                mysqli_real_escape_string($link, $dish->dish_name),
                mysqli_real_escape_string($link, $dish->dish_type),
                mysqli_real_escape_string($link, "Images/Dish/" . $dish->dish_image),
                mysqli_real_escape_string($link, $dish->dish_description));
                          
        $this->PerformQuery($query);
    }

    function DeleteDish($id) {
        require 'Credentials.php';
        //Opening connection and choosing database   
        $link = mysqli_connect($host, $user, $passwd, $database);
        if(!$link) {
			echo "Error: Unable to connect to MySQL.".PHP_EOL;
			echo "Debugging errno".mysqli_connect_errno().PHP_EOL;
			echo "Debugging error".mysqli_connect_error().PHP_EOL;
			exit;
		}
		
		$query = "DELETE FROM dish WHERE dish_id = $id";
        $this->PerformQuery($query);
    }

    function PerformQuery($query) {
        require 'Credentials.php';
        $link = mysqli_connect($host, $user, $passwd, $database);
        $result =  mysqli_query( $link, $query);
        
       //mysqli_free_result($result);
        //Execute query and close connection
        //mysqli_query( $link, $query);
        mysqli_close($link);
    }

}

?>
